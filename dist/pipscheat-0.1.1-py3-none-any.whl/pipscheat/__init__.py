import os

__all__ = ["cheat.py"]