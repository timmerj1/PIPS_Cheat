# PIPS_Cheat

Defines a function to "cheat" the python assignments in PIPS at UvA.
