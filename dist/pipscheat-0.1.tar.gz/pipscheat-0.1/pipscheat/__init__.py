import os

__all__ = ["cheat.py", "Assignment_1.2.py", "Assignment_2.2.py",
           "Assignment_3.2.py"]